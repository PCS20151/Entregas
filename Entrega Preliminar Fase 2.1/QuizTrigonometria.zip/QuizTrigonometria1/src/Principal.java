public class Principal {
	
	static int lado1 = 0;
	static int lado2 = 0;
	static int lado3 = 0;
	static double angulo1 = 0;
	static double angulo2 = 0;
	static double angulo3 = 0;
	static boolean a = true; 
	public static void main(String[] args) {
								
				System.out.printf("MAIN DE TESTE\n");
	while (a == true){
		Triangulo.gerarTriangulo(lado1,lado2,lado3);
		Triangulo.gerarAngulos();
		a = Triangulo.verificaGabErr();
	}
	int perimetro = Triangulo.perimetro(lado1, lado2, lado3);
	double area = Triangulo.Area(lado1, lado2, lado3);
	
		System.out.printf("Os lados são:\n / %d cm \n / %d cm \n / %d cm \n", lado1, lado2, lado3);
		System.out.printf("O perimetro é: %d cm \n",perimetro);
		System.out.printf("A área é: %.1f cm²\n",area);
		System.out.printf("Os angulos são:\n / %.1f  \n / %.1f  \n / %.1f  \n", angulo1, angulo2, angulo3);
	
	}
}